"""API do F.O.G.O. – Parte 1 (inventário). Rotas finas: a lógica está em catalogo.py e repo.py."""
import os
import sqlite3
from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, Query
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import catalogo, repo
from .db import iniciar, sessao
from .seed import semear

STATIC = os.path.join(os.path.dirname(__file__), "static")


@asynccontextmanager
async def lifespan(_app):
    iniciar()
    with sessao() as conn:
        semear(conn)          # só popula se o banco estiver vazio
    yield


app = FastAPI(title="F.O.G.O. – Ferramenta Onisciente de Gestão e Operações", lifespan=lifespan)


@app.exception_handler(catalogo.ValidacaoErro)
def _validacao(_req, exc):
    return JSONResponse({"erros": exc.erros}, status_code=422)


@app.exception_handler(repo.NaoEncontrado)
def _nao_encontrado(_req, exc):
    return JSONResponse({"erro": str(exc)}, status_code=404)


@app.exception_handler(sqlite3.IntegrityError)
def _integridade(_req, exc):
    msg = "Já existe um registro com esse número de série/matrícula" if "UNIQUE" in str(exc) \
        else "Referência inválida (equipamento inexistente?)"
    return JSONResponse({"erro": msg}, status_code=409)


# ------------------------------------------------------------------ metadados
@app.get("/api/tipos")
def tipos():
    """Tudo que o formulário precisa: tipos (com campos próprios), situações e listas fixas."""
    return {
        "tipos": {k: {"rotulo": v["rotulo"], "campos": v["campos"], "movel": k in catalogo.MOVEIS}
                  for k, v in catalogo.TIPOS.items()},
        "situacoes": catalogo.SITUACOES,
        "manutencoes": catalogo.MANUTENCOES,
        "funcoes_agente": catalogo.FUNCOES_AGENTE,
        "situacoes_agente": catalogo.SITUACOES_AGENTE,
    }


# ---------------------------------------------------------------- equipamentos
@app.get("/api/equipamentos")
def listar_equipamentos(tipo: str | None = None, situacao: str | None = None, bairro: str | None = None,
                        orgao: str | None = None, manutencao: str | None = None, q: str | None = None,
                        limite: int = Query(500, ge=1, le=2000), deslocamento: int = Query(0, ge=0)):
    with sessao() as conn:
        return repo.listar_equipamentos(conn, tipo, situacao, bairro, orgao, manutencao, q, limite, deslocamento)


@app.post("/api/equipamentos", status_code=201)
def criar_equipamento(dados: dict = Body(...)):
    with sessao() as conn:
        return repo.criar_equipamento(conn, dados)


@app.get("/api/equipamentos/{eq_id}")
def obter_equipamento(eq_id: int):
    with sessao() as conn:
        return repo.obter_equipamento(conn, eq_id)


@app.patch("/api/equipamentos/{eq_id}")
def atualizar_equipamento(eq_id: int, mudancas: dict = Body(...)):
    with sessao() as conn:
        return repo.atualizar_equipamento(conn, eq_id, mudancas)


@app.delete("/api/equipamentos/{eq_id}", status_code=204)
def excluir_equipamento(eq_id: int):
    with sessao() as conn:
        repo.excluir_equipamento(conn, eq_id)


# --------------------------------------------------------------------- agentes
@app.get("/api/agentes")
def listar_agentes(funcao: str | None = None, situacao: str | None = None,
                   orgao: str | None = None, q: str | None = None):
    with sessao() as conn:
        return repo.listar_agentes(conn, funcao, situacao, orgao, q)


@app.post("/api/agentes", status_code=201)
def criar_agente(dados: dict = Body(...)):
    with sessao() as conn:
        return repo.criar_agente(conn, dados)


@app.get("/api/agentes/{ag_id}")
def obter_agente(ag_id: int):
    with sessao() as conn:
        return repo.obter_agente(conn, ag_id)


@app.patch("/api/agentes/{ag_id}")
def atualizar_agente(ag_id: int, mudancas: dict = Body(...)):
    with sessao() as conn:
        return repo.atualizar_agente(conn, ag_id, mudancas)


@app.delete("/api/agentes/{ag_id}", status_code=204)
def excluir_agente(ag_id: int):
    with sessao() as conn:
        repo.excluir_agente(conn, ag_id)


# ------------------------------------------------------------------- interface
@app.get("/", include_in_schema=False)
def raiz():
    index = os.path.join(STATIC, "index.html")
    return FileResponse(index) if os.path.exists(index) else RedirectResponse("/docs")


app.mount("/static", StaticFiles(directory=STATIC), name="static")
